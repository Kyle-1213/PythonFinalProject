""" classFunction.py 
        
        Created by Kyle LeDoux
            Final Python Project in CS212 
    """
class Function():
    """
    Class will eventually contain attributes for
    each function.
    This will be a super class, where eventually every
    line in the funciton will have it's own attributes
    like memory address, hex value, instruction command,
    registers used. 
    """
    def __init__(self):
        1==1